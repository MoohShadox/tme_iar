class MSELoss(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  reduction : Final[str] = "mean"
  def forward(self: __torch__.torch.nn.modules.loss.MSELoss,
    input: Tensor,
    target: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.mse_loss
    _1 = _0(input, target, None, None, "mean", )
    return _1
