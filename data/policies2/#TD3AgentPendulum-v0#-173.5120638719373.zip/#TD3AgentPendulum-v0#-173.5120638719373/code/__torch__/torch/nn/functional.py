def linear(input: Tensor,
    weight: Tensor,
    bias: Optional[Tensor]=None) -> Tensor:
  if torch.eq(torch.dim(input), 2):
    _0 = torch.__isnot__(bias, None)
  else:
    _0 = False
  if _0:
    bias0 = unchecked_cast(Tensor, bias)
    ret0 = torch.addmm(bias0, input, torch.t(weight), beta=1, alpha=1)
    ret = ret0
  else:
    output = torch.matmul(input, torch.t(weight))
    if torch.__isnot__(bias, None):
      bias1 = unchecked_cast(Tensor, bias)
      output1 = torch.add_(output, bias1, alpha=1)
      output0 = output1
    else:
      output0 = output
    ret = output0
  return ret
