class TD3_Actor(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  state_dim : int
  action_dim : int
  max_action : int
  layer_norm : bool
  l1 : __torch__.torch.nn.modules.linear.Linear
  l2 : __torch__.torch.nn.modules.linear.___torch_mangle_0.Linear
  l3 : __torch__.torch.nn.modules.linear.___torch_mangle_1.Linear
  def forward(self: __torch__.policies.td3_actor.TD3_Actor,
    x: Tensor) -> Tensor:
    x0 = torch.tanh((self.l1).forward(x, ))
    x1 = torch.tanh((self.l2).forward(x0, ))
    _0 = self.max_action
    x2 = torch.mul(torch.tanh((self.l3).forward(x1, )), _0)
    return x2
  def select_action(self: __torch__.policies.td3_actor.TD3_Actor,
    state: List[float],
    deterministic: bool=False) -> List[float]:
    state0 = torch.tensor(state, dtype=None, device=None, requires_grad=False)
    action = (self).forward(state0, )
    act = annotate(List[float], ops.prim.data(action).tolist())
    return act
