def relu(input: Tensor,
    inplace: bool=False) -> Tensor:
  if inplace:
    result = torch.relu_(input)
  else:
    result = torch.relu(input)
  return result
def mse_loss(input: Tensor,
    target: Tensor,
    size_average: Optional[bool]=None,
    reduce: Optional[bool]=None,
    reduction: str="mean") -> Tensor:
  _0 = "Using a target size ({}) that is different to the input size ({}). This will likely lead to incorrect results due to broadcasting. Please ensure they have the same size."
  _1 = __torch__.torch.nn._reduction.legacy_get_string
  _2 = __torch__.torch.nn._reduction.get_enum
  _3 = torch.eq(torch.size(target), torch.size(input))
  if torch.__not__(_3):
    _4 = torch.format(_0, torch.size(target), torch.size(input))
    torch.warn(_4, 2)
  else:
    pass
  if torch.__isnot__(size_average, None):
    _5, size_average0 = True, unchecked_cast(bool, size_average)
  else:
    _5, size_average0 = torch.__isnot__(reduce, None), size_average
  if _5:
    reduction0 = _1(size_average0, reduce, True, )
  else:
    reduction0 = reduction
  if ops.prim.requires_grad(target):
    ret0 = torch.pow(torch.sub(input, target, alpha=1), 2)
    if torch.ne(reduction0, "none"):
      if torch.eq(reduction0, "mean"):
        ret2 = torch.mean(ret0, dtype=None)
      else:
        ret2 = torch.sum(ret0, dtype=None)
      ret1 = ret2
    else:
      ret1 = ret0
    ret = ret1
  else:
    _6 = torch.broadcast_tensors([input, target])
    expanded_input, expanded_target, = _6
    ret3 = torch.mse_loss(expanded_input, expanded_target, _2(reduction0, ))
    ret = ret3
  return ret
def linear(input: Tensor,
    weight: Tensor,
    bias: Optional[Tensor]=None) -> Tensor:
  if torch.eq(torch.dim(input), 2):
    _7 = torch.__isnot__(bias, None)
  else:
    _7 = False
  if _7:
    bias0 = unchecked_cast(Tensor, bias)
    ret4 = torch.addmm(bias0, input, torch.t(weight), beta=1, alpha=1)
    ret = ret4
  else:
    output = torch.matmul(input, torch.t(weight))
    if torch.__isnot__(bias, None):
      bias1 = unchecked_cast(Tensor, bias)
      output1 = torch.add_(output, bias1, alpha=1)
      output0 = output1
    else:
      output0 = output
    ret = output0
  return ret
